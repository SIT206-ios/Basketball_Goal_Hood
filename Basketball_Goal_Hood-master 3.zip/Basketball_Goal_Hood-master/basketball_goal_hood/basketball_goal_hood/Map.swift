//
//  Map.swift
//  basketball_goal_hood
//
//  Created by YINNENG DU on 21/05/2017.
//  Copyright © 2017 YINNENG DU. All rights reserved.


import UIKit
import MapKit
import CoreLocation
class Map: UIViewController, MKMapViewDelegate {


    
    @IBOutlet weak var MapView: MKMapView!
    
    let locationManager: CLLocationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //set center
        let latDelta = 0.05
        let longDelta = 0.05
        let currentLocationSpan: MKCoordinateSpan = MKCoordinateSpanMake(latDelta,longDelta)
        let center:CLLocation = CLLocation(latitude: 41.4987791, longitude: -81.7163405)
        let currentRegion:MKCoordinateRegion = MKCoordinateRegion(center: center.coordinate, span: currentLocationSpan)
        self.MapView.setRegion(currentRegion, animated: true)
        
        
        //Display the detail below on the MkMapView
        let objectAnnotation1 = MKPointAnnotation()
        objectAnnotation1.coordinate = CLLocation(latitude: 41.4987791,longitude: -81.7163405).coordinate
        objectAnnotation1.title = "Cavalieris"
        objectAnnotation1.subtitle = "1 Center Ct, Cleveland, OH 44115"
        self.MapView.addAnnotation(objectAnnotation1)

        
        let objectAnnotation2 = MKPointAnnotation()
        objectAnnotation2.coordinate = CLLocation(latitude: 37.802956,longitude: -122.273357).coordinate
        objectAnnotation2.title = "Warrior"
        objectAnnotation2.subtitle = "7000 Joe Morgan Way Oakland, CA 94621"
        self.MapView.addAnnotation(objectAnnotation2)
        

        let objectAnnotation3 = MKPointAnnotation()
        objectAnnotation3.coordinate = CLLocation(latitude: 29.426934,longitude: -98.437479).coordinate
        objectAnnotation3.title = "Spurs"
        objectAnnotation3.subtitle = "13581 Pond Spring Rd #108, Austin, TX 78729"
        self.MapView.addAnnotation(objectAnnotation3)

        let objectAnnotation4 = MKPointAnnotation()
        objectAnnotation4.coordinate = CLLocation(latitude: 28.554119,longitude: -81.184517).coordinate
        objectAnnotation4.title = "Lakers"
        objectAnnotation4.subtitle = "1411 Maple Ave, Los Angeles, CA 90015"
        self.MapView.addAnnotation(objectAnnotation4)
        
        let objectAnnotation5 = MKPointAnnotation()
        objectAnnotation5.coordinate = CLLocation(latitude: 40.689812,longitude: -73.729251).coordinate
        objectAnnotation5.title = "Knicks"
        objectAnnotation5.subtitle = "20 5th Ave #95, New York, NY 10011"
        self.MapView.addAnnotation(objectAnnotation5)
        
        let objectAnnotation6 = MKPointAnnotation()
        objectAnnotation6.coordinate = CLLocation(latitude: 39.750708,longitude: -76.586175).coordinate
        objectAnnotation6.title = "Piston"
        objectAnnotation6.subtitle = "12723 Telegraph Rd, Redford Charater Twp, Mi 48239"
        self.MapView.addAnnotation(objectAnnotation6)
    }
    
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
