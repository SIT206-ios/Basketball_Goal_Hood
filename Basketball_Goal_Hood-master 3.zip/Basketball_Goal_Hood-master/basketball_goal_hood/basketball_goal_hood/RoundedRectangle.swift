//
//  RoundedRectangle.swift
//  basketball_goal_hood
//
//  Created by YINNENG DU on 14/05/2017.
//  Copyright © 2017 YINNENG DU. All rights reserved.
//

import UIKit

@IBDesignable
class RoundedRectangle: UIButton {

    override func layoutSubviews() {
        super.layoutSubviews()
        CornerRadius()
        
    }
    
    // Change button to rounded rectangle
    @IBInspectable var rounded: Bool = false{
        didSet{
            CornerRadius()
        }
    }
    
    func CornerRadius(){
        layer.cornerRadius = rounded ? frame.size.height / 2 : 0
    }
    
    
}


extension ViewController{
    
}
