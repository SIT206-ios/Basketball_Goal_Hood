//
//  VideoTeaching.swift
//  basketball_goal_hood
//
//  Created by YINNENG DU on 18/05/2017.
//  Copyright © 2017 YINNENG DU. All rights reserved.
//

import UIKit

class VideoTeaching: UIViewController {

    
    func openurl(scheme: String){
        if let url = URL(string: scheme){
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
    //Use the link via url to connect to the video recommended
    @IBAction func BestCrossing(sender: UIButton){
        openurl(scheme: "https://www.youtube.com/watch?v=mD6dRet0Ul0")
    }
    
    @IBAction func CurryLegandary(sender: UIButton){
        openurl(scheme: "https://www.youtube.com/watch?v=zRRVlRvhHDk")
    }
    
    @IBAction func AmazingThree_Pointer(sender: UIButton){
        openurl(scheme: "https://www.youtube.com/watch?v=MsrRHmJHSrE")
    }
    
    @IBAction func Ten_Best_Goal(sender: UIButton){
        openurl(scheme: "https://www.youtube.com/watch?v=s3sY_N76CDE")
    }
    
    @IBAction func SpurVSWarrior(sender: UIButton){
        openurl(scheme: "https://www.youtube.com/watch?v=yRXm0LnZCK4")
    }
    
    @IBAction func KINGFIGHT(sender: UIButton){
        openurl(scheme: "https://www.youtube.com/watch?v=zL1hk8WbBNk")
    }
    
    @IBAction func SAVAGELEVEL(sender: UIButton){
        openurl(scheme: "https://www.youtube.com/watch?v=0-yh0hf7sBU")
    }
    
    @IBAction func MORE(sender: UIButton){
        openurl(scheme: "http://www.sportingnews.com/au/nba/videos")
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
