//
//  NBAWebsite.swift
//  basketball_goal_hood
//
//  Created by YINNENG DU on 18/05/2017.
//  Copyright © 2017 YINNENG DU. All rights reserved.
//

import UIKit

class NBAWebsite: UIViewController {
    
    
    //function for open the URL via the scheme from each button.
    func open(scheme: String) {
        if let url = URL(string: scheme){
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
    //Use to link via url to connect to the website
    @IBAction func HomeLink(sender: UIButton){
        open(scheme: "http://www.sportingnews.com/au/nba")
        //connect to the HOME of the NBA Website, and the buttons below are the same.
    }
    
    @IBAction func PhotosLink(sender: UIButton){
        open(scheme: "http://www.sportingnews.com/au/nba/photos")
    }
    
    @IBAction func VideoLink(sender: UIButton){
        open(scheme: "http://www.sportingnews.com/au/nba/videos")
    }
    
    @IBAction func ScoresLink(sender: UIButton){
        open(scheme: "http://au.global.nba.com/scores/")
    }
    
    @IBAction func ScheduleLink(sender: UIButton){
        open(scheme: "http://au.global.nba.com/schedule/#!/7")
    }
    
    @IBAction func StandingsLink(sender: UIButton){
        open(scheme: "http://au.global.nba.com/standings/")
    }
    
    @IBAction func StatsLink(sender: UIButton){
        open(scheme: "http://au.global.nba.com/statistics/teamstats/")
    }
    
    @IBAction func TeamsLink(sender: UIButton){
        open(scheme: "http://au.global.nba.com/teamindex/")
    }
    
    @IBAction func PlayersLink(sender: UIButton){
        open(scheme: "http://au.global.nba.com/playerindex/")
    }
    
    @IBAction func NewsArchiveLink(sender: UIButton){
        open(scheme: "http://www.sportingnews.com/au/nba/news")
    }
    
    @IBAction func StoreLink(sender: UIButton){
        open(scheme: "http://www.nbastore.com.au/")
    }
    
    @IBAction func PlayoffPictureLink(sender: UIButton){
        open(scheme: "http://au.global.nba.com/playoffs/")
    }
    
    @IBAction func DailyFantasyLink(sender: UIButton){
        open(scheme: "http://www.sportingnews.com/au/nba/daily-fantasy/")
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
