//
//  NBADetail.swift
//  basketball_goal_hood
//
//  Created by YINNENG DU on 19/05/2017.
//  Copyright © 2017 YINNENG DU. All rights reserved.
//

import UIKit

class NBADetail: UIViewController {



    @IBOutlet weak var NBAImage: UIImageView!

    @IBOutlet weak var TextDetail: UITextView!

    var dataset : Int?
    
    //Controller the view controller to display different data when click the different button when it get the data from NBA team
    func checkdata(){
        if dataset == 1
        {
            NBAImage.image = UIImage(named: "22")
            TextDetail.text = "LeBron Raymone James (/ləˈbrɒn/; born December 30, 1984) is an American professional basketball player for the Cleveland Cavaliers of the National Basketball Association (NBA). James has won three NBA championships, four NBA Most Valuable Player Awards, three NBA Finals MVP Awards, two Olympic gold medals, an NBA scoring title, and the NBA Rookie of the Year Award. He has also been selected to 13 NBA All-Star teams, 13 All-NBA teams, and six All-Defensive teams, and is the Cavaliers' all-time leading scorer."
        }
        if dataset == 2
        {
            NBAImage.image = UIImage(named: "23")
            TextDetail.text = "Earl Joseph 'J. R.' Smith III[1] (born September 9, 1985) is an American professional basketball player for the Cleveland Cavaliers of the National Basketball Association (NBA). He played high school basketball at New Jersey basketball powerhouse Saint Benedict's Preparatory School in Newark. Smith was recruited by the University of North Carolina but opted to enter the 2004 NBA draft. Over his NBA career, Smith has also played for the New Orleans Hornets, Denver Nuggets and New York Knicks."
        }
        if dataset == 3
        {
            NBAImage.image = UIImage(named: "24")
            TextDetail.text = "Kyle Elliot Korver[1] (born March 17, 1981) is an American professional basketball player for the Cleveland Cavaliers of the National Basketball Association (NBA). He played college basketball for Creighton and was drafted with the 51st overall pick in the 2003 NBA draft by the New Jersey Nets. Korver became an NBA All-Star for the first time in 2015, and holds the NBA record for the highest three-point field goal percentage in a season (with 53.6%)."
        }
    }
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkdata()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
