//
//  ShopAtUs.swift
//  basketball_goal_hood
//
//  Created by YINNENG DU on 19/05/2017.
//  Copyright © 2017 YINNENG DU. All rights reserved.
//

import UIKit

class ShopAtUs: UIViewController {
    
    var select1 : Int = 1
    var select2 : Int = 2
    var select3 : Int = 3
    var select4 : Int = 4
    var setImage: UIImage?
    @IBAction func GetImage(_ sender: UIButton) {
        
        
    }
    
    //Via segue to send the data to ShopDetail
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "setsegue1"{
            (segue.destination as! ShopDetail).imagedata1 = select1
        }
        if segue.identifier == "setsegue2"{
            (segue.destination as! ShopDetail).imagedata1 = select2
        }
        if segue.identifier == "setsegue3"{
            (segue.destination as! ShopDetail).imagedata1 = select3
        }
        if segue.identifier == "setsegue4"{
            (segue.destination as! ShopDetail).imagedata1 = select4
        }
        
    }
    
    
    
    

    
    override func viewDidLoad() {
        super.viewDidLoad()


        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
