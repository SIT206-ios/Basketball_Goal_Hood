//
//  ShopDetail.swift
//  basketball_goal_hood
//
//  Created by YINNENG DU on 19/05/2017.
//  Copyright © 2017 YINNENG DU. All rights reserved.
//

import UIKit

class ShopDetail: UIViewController {


    @IBOutlet weak var getImage: UIImageView!
        
    @IBOutlet weak var ShopName: UILabel!
    @IBOutlet weak var Price: UILabel!
    @IBOutlet weak var DateListed: UILabel!
    @IBOutlet weak var LastEdited: UILabel!
    @IBOutlet weak var Condition: UILabel!

    
    @IBAction func CheckOut(_ sender: UIButton) {
    }

    
    
    
    
    
    var imagedata1 : Int?
    
    
    //Controll the view controller to get data from ShopAsUs and do the choice to show the detail
    func checkdata(){
        if imagedata1 == 1
        {
            getImage.image = UIImage(named: "11")
            ShopName.text = "KOBE's 7TH BOOT"
            Price.text = "$299.9"
            DateListed.text = "18/05/2017"
            LastEdited.text = "18/05/2017"
            Condition.text = "New"
        }
        if imagedata1 == 2
        {
            getImage.image = UIImage(named: "12")
            ShopName.text = "LEBRON 8TH BOOT"
            Price.text = "$300.0"
            DateListed.text = "18/05/2017"
            LastEdited.text = "18/05/2017"
            Condition.text = "New"
        }
        if imagedata1 == 3
        {
            getImage.image = UIImage(named: "13")
            ShopName.text = "BULL TEAM SHIRT"
            Price.text = "$50.0"
            DateListed.text = "18/05/2017"
            LastEdited.text = "18/05/2017"
            Condition.text = "New"
        }
        if imagedata1 == 4
        {
            getImage.image = UIImage(named: "14")
            ShopName.text = "KOBE's 7TH BOOT"
            Price.text = "$299.9"
            DateListed.text = "18/05/2017"
            LastEdited.text = "18/05/2017"
            Condition.text = "New"
        }
    }
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkdata()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
