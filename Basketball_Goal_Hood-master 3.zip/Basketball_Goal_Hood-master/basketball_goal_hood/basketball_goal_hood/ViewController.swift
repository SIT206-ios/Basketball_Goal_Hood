//
//  ViewController.swift
//  basketball_goal_hood
//
//  Created by YINNENG DU on 29/04/2017.
//  Copyright © 2017 YINNENG DU. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController{

    var gravity : UIGravityBehavior?
    var animator : UIDynamicAnimator?
    var gameTimer: Timer?
    var soundPlayer: AVAudioPlayer?
    var elapsedTime: TimeInterval = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //Music
        let path = Bundle.main.path(forResource: "WeWillRockYou", ofType: "mp3")
        let url = URL(fileURLWithPath: path!)
        
        do{
            try soundPlayer = AVAudioPlayer(contentsOf: url)
        }
        catch{
            print("file not available")
        }
        

        
        //Animation
        gameTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.basketball(_:)), userInfo: nil, repeats: true)
        
        animator = UIDynamicAnimator(referenceView: self.view)
        gravity = UIGravityBehavior(items: [])
        
        let vector = CGVector(dx: 0.0, dy: 0.1)
        gravity?.gravityDirection = vector
        animator?.addBehavior(gravity!)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //Set basketball detail and button
    func basketball(_ : Any){
        let Xcoordinate = arc4random() % UInt32(self.view.bounds.width)
        
        let btn = UIButton(frame: CGRect(x: Int(Xcoordinate), y: 60, width: 50, height: 50))
            
        btn.setImage(UIImage(named: "Basketball"), for: .normal)
        btn.addTarget(self, action: #selector(self.didbreak(sender:)), for: .touchUpInside)
        self.view.addSubview(btn)
        
        gravity?.addItem((btn as UIView))
        
    }

    //Set animation after click
    func didbreak(sender: UIButton){
        sender.setImage(UIImage(named: "exploded"), for: .normal)
        UIView.animate(withDuration: 0.4, animations: {sender.alpha = 0}, completion: {(true) in sender.removeFromSuperview()})
    }


    @IBAction func on(_ sender: UIButton) {
        if soundPlayer != nil{
            soundPlayer!.currentTime = elapsedTime
            soundPlayer!.play()
        }
    }
    
    
    @IBAction func off(_ sender: UIButton) {
        if soundPlayer != nil{
            soundPlayer!.stop()
            elapsedTime = 0
            
        }
    
    }
    
    
}
