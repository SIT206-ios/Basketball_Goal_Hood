//
//  PaymentMethod.swift
//  basketball_goal_hood
//
//  Created by YINNENG DU on 20/05/2017.
//  Copyright © 2017 YINNENG DU. All rights reserved.
//

import UIKit

class PaymentMethod: UIViewController {

    
    var BankAccountNumber : String?
    var SecurityCode: String?
    var ExpireDate: String?
    var Country: String?
    var City: String?
    var Address: String?
    
    @IBOutlet weak var BankAccountNumberText: UITextField!
    @IBOutlet weak var SecurityCodeText: UITextField!
    @IBOutlet weak var ExpireDateText: UITextField!
    @IBOutlet weak var CountryText: UITextField!
    @IBOutlet weak var CityText: UITextField!
    @IBOutlet weak var AddressText: UITextField!
    
    
    
    
    //Set the value
    func input(){
        BankAccountNumber = BankAccountNumberText.text
        SecurityCode = SecurityCodeText.text
        ExpireDate = ExpireDateText.text
        Country = CountryText.text
        City = CityText.text
        Address = AddressText.text
    }
    
    
    //Clean the text
    func clean(){
        BankAccountNumberText.text = ""
        SecurityCodeText.text = ""
        ExpireDateText.text = ""
        CountryText.text = ""
        CityText.text = ""
        AddressText.text = ""
    }
    
    //Check the data whether valid in the each text or not
    @IBAction func Pay(_ sender: UIButton) {
        input()
        if BankAccountNumber == "" || SecurityCode == "" || ExpireDate == "" || Country == "" || City == "" || Address == ""{
            let alertController = UIAlertController(title: "Error", message: "Invalid Submit, try again.", preferredStyle: .alert)
            let verify = UIAlertAction(title: "OK", style: .default){
                (action) -> Void in print("Invalid Submit")
            }
            
            alertController.addAction(verify)
            self.present(alertController, animated: true, completion: nil)
        }
        else {
            let alertController = UIAlertController(title: "Submit Succeed", message: "You have submit it.", preferredStyle: .alert)
            let verify = UIAlertAction(title: "OK", style: .default){
                (action) -> Void in print("Submit Succeed")
            }
            
            alertController.addAction(verify)
            self.present(alertController, animated: true, completion: nil)
            clean()
        }
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
