//
//  Feedback.swift
//  basketball_goal_hood
//
//  Created by YINNENG DU on 17/05/2017.
//  Copyright © 2017 YINNENG DU. All rights reserved.
//

import UIKit

class Feedback: UIViewController {

    
    var name: String?
    var phone: String?
    var email: String?
    var content: String?
    
    
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfPhone: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tvContent: UITextView!
    
    //Set value.
   func input()
    {
        name = tfName.text
        phone = tfPhone.text
        email = tfEmail.text
        content = tvContent.text
    }
    
    //Clean the text
    func clean()
    {
        tfName.text = ""
        tfPhone.text = ""
        tfEmail.text = ""
        tvContent.text = ""
    }
    
    //Check the data whether valid in each text or not
    @IBAction func Submit(_ sender: UIButton) {
        input()
        if name == "" || phone == "" || email == "" || content == ""{
            let alertController = UIAlertController(title: "Error", message: "Invalid Submit, try again.", preferredStyle: .alert)
            let verify = UIAlertAction(title: "OK", style: .default){
                (action) -> Void in print("Invalid Submit")
            }
            
            alertController.addAction(verify)
            self.present(alertController, animated: true, completion: nil)
        }
        else {
            let alertController = UIAlertController(title: "Submit Succeed", message: "You have submit it.", preferredStyle: .alert)
            let verify = UIAlertAction(title: "OK", style: .default){
                (action) -> Void in print("Submit Succeed")
            }
            
            alertController.addAction(verify)
            self.present(alertController, animated: true, completion: nil)
            
            clean()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    
    
    
    
    
}
